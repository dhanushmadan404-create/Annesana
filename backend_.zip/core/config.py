from DB.database import SessionLocal
def connect_db():
    # connection operation
    db = SessionLocal()
    try:
        print("DataBase Connected successfully")
        yield db
    finally:
        db.close()

