psql -u postgres -w \\\

pip freeze > requirements.txt\\

acid theory \\

METADATA IS ALL DETAIL IN THIS FILE//

yeid is return db\\

abord or close()


separation of concern


file structure=models--->align file->schema--->align file->db->routers--->align,,->dependence--connection