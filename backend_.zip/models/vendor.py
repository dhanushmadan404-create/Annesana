from DB.database import Base
from sqlalchemy import Column,String,Integer,Boolean,TIMESTAMP,ForeignKey


class vendors(Base):
    __tablename__="vendors"

    vendor_id=Column(Integer,index=True, primary_key=True)
    vendor_name=Column(String)
    cart_name=Column(String)
    food_type=Column(String)  
    phone_number=Column(String)
    location_id=Column(Integer,ForeignKey("locations.location_id"))
    cart_image=Column(String)
    opening_time=Column(TIMESTAMP)
    closing_time=Column(TIMESTAMP)

