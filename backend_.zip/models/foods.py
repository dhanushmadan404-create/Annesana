from DB.database import Base
from sqlalchemy import Column,String,Integer,Boolean,TIMESTAMP,ForeignKey,Numeric

class foods(Base):
    __tablename__="foods"

    food_id=Column(Integer,index=True, primary_key=True)
    vendor_id=Column(Integer,ForeignKey("vendors.vendor_id"))
    food_name=Column(String)
    food_image=Column(String)