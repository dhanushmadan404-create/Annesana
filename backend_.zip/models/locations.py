from DB.database import Base
from sqlalchemy import Column,String,Integer,Boolean,TIMESTAMP,ForeignKey,Numeric

class locations(Base):
    __tablename__="locations"

    location_id=Column(Integer,index=True, primary_key=True)
    location_name=Column(String)
    latitude=Column(Numeric)
    longitude=Column(Numeric)