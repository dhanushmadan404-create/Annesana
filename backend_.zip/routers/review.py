from main import app
from fastapi import Depends 
from sqlalchemy.orm import Session
from schemas.review_base import reviewBase,reviewResponse
from models.reviews import reviews
from core.config import connect_db

@app.post("/users", response_model=reviewResponse)
def create_user(userReview: reviewBase, dbs: Session = Depends(connect_db)):
    u=reviews(
        rating=userReview.rating,
        comment=userReview.comment,
        created_at=userReview.created_at
        
    )
    
    dbs.add(u)
    dbs.commit()
    dbs.refresh(u)
    return u