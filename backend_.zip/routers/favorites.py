from main import app
from fastapi import Depends 
from sqlalchemy.orm import Session
from schemas.favorites_base import favorites_Base,favorites_Response
from models.favorites import favorites
from core.config import connect_db

@app.post("/users", response_model=favorites_Response)
def create_user(userFavorites: favorites_Base, dbs: Session = Depends(connect_db)):
    fav=favorites(
        created_at=userFavorites.created_at
        
    )
    
    dbs.add(fav)
    dbs.commit()
    dbs.refresh(fav)
    return fav