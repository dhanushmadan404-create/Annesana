from main import app
from fastapi import Depends 
from sqlalchemy.orm import Session
from schemas.user_base import UserBase, UserResponse
from models.user import Users
from core.config import connect_db

@app.post("/users", response_model=UserResponse)
def create_user(new_user: UserBase, dbs: Session = Depends(connect_db)):
    u = Users(
        email=new_user.email,
        created_at=new_user.created_at,
        password_hash=new_user.password_hash,
        role=new_user.role
    )
    dbs.add(u)
    dbs.commit()
    dbs.refresh(u)
    return u