from main import app
from fastapi import Depends 
from sqlalchemy.orm import Session
from schemas.vendor_base import vendor_base, vendor_response
from models.vendor import vendors
from core.config import connect_db
from models.foods import foods
from models.locations import locations

@app.post("/users", response_model=vendor_response)
def create_vendor(new_vendor: vendor_base, dbs: Session = Depends(connect_db)):

    vendor_name=new_vendor.vendor_name,
    cart_name=new_vendor.cart_name,
    food_type=new_vendor.food_type,
    phone_number=new_vendor.phone_number,
    location_name=new_vendor.location_name,
    longitude=new_vendor.longitude,
    latitude=new_vendor.latitude,
    cart_image=new_vendor.cart_image,
    opening_time=new_vendor.opening_time,
    closing_time=new_vendor.closing_time
    
    v= vendors(
        vendor_name=vendor_name,
        cart_name=cart_name,
        food_type=food_type,
        phone_number=phone_number,
        cart_image=cart_image,
        opening_time=opening_time,
        closing_time=closing_time
    )
   
    food_name=new_vendor.menu_list, 
    food_image=new_vendor.cart_image
    f= foods(
        food_name=food_name, 
        food_image=food_image)
    l= locations(
        location_name=location_name,
        longitude=longitude,
        latitude=latitude
    )
    dbs.add(f)
    dbs.commit()
    dbs.refresh(f)
    
    dbs.add(l)
    dbs.commit()
    dbs.refresh(l)

    dbs.add(v)
    dbs.commit()
    dbs.refresh(v)
    return v,f,l