from pydantic import BaseModel

class reviewBase(BaseModel):
    rating:int
    comment:str
    created_at:str

class reviewCreate(reviewBase):
    pass

class reviewResponse(reviewBase):
    review_id:int
    user_id:int
    vendor_id:int
    class config:
        from_attributes=True