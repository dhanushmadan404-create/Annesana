from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class favoriteBase(BaseModel):
    # On create, you may omit created_at — DB will fill it
    created_at: Optional[datetime] = None
    user_id: int
    food_id: int

class favoriteResponse(favoriteBase):
    favorite_id: int

    class Config:
        orm_mode = True
