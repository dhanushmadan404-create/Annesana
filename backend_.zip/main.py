from fastapi import FastAPI
from DB.database import  engine, Base


app = FastAPI()
Base.metadata.create_all(bind=engine)


from routers import favorites   
app.include_router(favorites.router)